#Teacher sample file 1
#Filename: oscillatory_2672601.csv
#This uses 5 + d2 = 5 rows since d2 = 0.
#Teacher sample file 2
#Filename: standing_2672601.csv
#This uses 4 + rows_keep = 7 rows since rows_keep = 3.
from os import path
import numpy as np
import math
def read_oscillatory_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
 
    #data = np.loadtxt(filename, delimiter=',')  # Assuming CSV format
    lengths = data[:, 0]
    amplitudes = data[:, 1]
    mean_amp = np.mean(amplitudes)
    max_amp = np.max(amplitudes)
    return lengths, amplitudes, mean_amp, max_amp


def read_standing_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
    lengths = data[:, 0]
    tensions = data[:, 1]
    speeds = np.sqrt(tensions / 1)
    return lengths, tensions, speeds


def main():
    student_id = 2578028
    d1 = student_id % 10 #last digit of student ID
    d2 = (student_id // 10) % 10 #second-last digit of student ID
    k = (d1 + d2) % 4 + 2
    shift = d1 - d2
    rows_keep = (d1 % 2) + 2
    print("Student ID values:")
    print(f"d1 = {d1}, d2 = {d2}, k = {k}, shift = {shift}, rows_keep = {rows_keep}")

    osc_file = f"oscillatory_{student_id}.csv"
    stand_file = f"standing_{student_id}.csv"
 
    lengths1, amplitudes, mean_amp, max_amp = read_oscillatory_wave_data(osc_file)

    print("Original oscillatory amplitudes:", amplitudes)
    print("Original mean amplitude:", mean_amp)
    print("Original max amplitude:", max_amp)

    lengths1 = lengths1[:5 + d2]
    amplitudes = amplitudes[:5 + d2]
    new_amplitudes = amplitudes + shift
    new_mean_amp = np.mean(new_amplitudes)
    new_max_amp = np.max(new_amplitudes)

    print("\nShifted amplitudes:", new_amplitudes)
    print("New mean amplitude:", new_mean_amp)
    print("New max amplitude:", new_max_amp)

    lengths2, tensions, speeds = read_standing_wave_data(stand_file)

    print("\nOriginal tensions:", tensions)
    print("Original wave speeds:", speeds)

    lengths2 = lengths2[:4 + rows_keep]
    tensions = tensions[:4 + rows_keep]
    new_tensions = tensions * k
    new_speeds = np.sqrt(new_tensions)   

    print("\nScaled tensions:", new_tensions)
    print("New wave speeds:", new_speeds)

    print("\nManual oscillatory check using first 3 amplitudes:")
    print("Original first 3 amplitudes:", amplitudes[:3])
    print("Shifted first 3 amplitudes:", new_amplitudes[:3])

    print("\nManual standing-wave check using first row:")
    print("First tension =", tensions[0])
    print("Scaled first tension =", new_tensions[0])
    print("First new speed =", math.sqrt(new_tensions[0]))


if __name__ == "__main__":
    main()
